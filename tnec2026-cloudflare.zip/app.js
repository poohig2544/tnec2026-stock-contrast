/* ==============================================================================
   🌸 TNEC 2026 - Contrast Media Inventory
   ศูนย์รังสีร่วมรักษาระบบประสาท โรงพยาบาลตากสิน
   Application Client Logic (app.js)
   ============================================================================== */

let currentTab = 'dashboard';
let currentSyncVersion = null;
let summaryData = null;
let allStocks = [];
let allUsages = [];
let pollingInterval = null;

// Initial Load
document.addEventListener('DOMContentLoaded', () => {
  initApp();
});

async function initApp() {
  // Set default dates
  const today = new Date().toISOString().split('T')[0];
  const usageDateInput = document.getElementById('formUsageDate');
  if (usageDateInput) usageDateInput.value = today;

  // Restore saved recorder name if available
  const savedRecorder = localStorage.getItem('last_contrast_recorder');
  if (savedRecorder) {
    const stockRec = document.getElementById('formStockRecorder');
    const usageRec = document.getElementById('formUsageRecorder');
    if (stockRec) stockRec.value = savedRecorder;
    if (usageRec) usageRec.value = savedRecorder;
  }

  // Load initial data
  await refreshAllData();

  // Start Realtime Polling (Every 3 seconds)
  startSyncPolling();
}

// ==============================================================================
// 🔄 Realtime Sync Polling
// ==============================================================================
function startSyncPolling() {
  if (pollingInterval) clearInterval(pollingInterval);
  pollingInterval = setInterval(async () => {
    try {
      const res = await fetch('/api/sync-version');
      if (res.ok) {
        const data = await res.json();
        if (currentSyncVersion && data.version !== currentSyncVersion) {
          // Version updated by another user!
          showSyncIndicator(true);
          await refreshAllData(false);
          showToast('มีการอัปเดตข้อมูลจากสมาชิกในทีม ✨', 'success');
        }
        currentSyncVersion = data.version;
      }
    } catch (err) {
      console.warn('Sync polling paused:', err);
    }
  }, 3000);
}

function showSyncIndicator(isBlinking = false) {
  const el = document.getElementById('syncStatusIndicator');
  if (!el) return;
  if (isBlinking) {
    el.style.backgroundColor = '#FFF0F4';
    el.style.borderColor = '#FFD2DE';
    setTimeout(() => {
      el.style.backgroundColor = 'var(--pastel-mint-light)';
      el.style.borderColor = 'var(--pastel-mint-border)';
    }, 1200);
  }
}

// ==============================================================================
// 📊 Fetch & Refresh All Data
// ==============================================================================
async function refreshAllData(showLoading = true) {
  try {
    const [summaryRes, stocksRes] = await Promise.all([
      fetch('/api/summary'),
      fetch('/api/stock?all=1')
    ]);

    if (summaryRes.ok && stocksRes.ok) {
      summaryData = await summaryRes.json();
      allStocks = await stocksRes.json();

      renderMetrics(summaryData);
      renderDashboardBrands(summaryData.brands);
      renderStockTable();
      populateUsageStockDropdown();

      if (currentTab === 'usage-logs') {
        await loadUsageLogs();
      }
    }
  } catch (err) {
    console.error('Error refreshing data:', err);
    showToast('ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้ในขณะนี้', 'error');
  }
}

// ==============================================================================
// 📈 Render Metrics
// ==============================================================================
function renderMetrics(data) {
  document.getElementById('metricTotalBottles').textContent = (data.total_bottles || 0).toLocaleString();
  
  const lowStockCountEl = document.getElementById('metricLowStockCount');
  lowStockCountEl.textContent = data.low_stock_brands_count || 0;
  
  const lowCard = document.getElementById('metricLowStockCard');
  if (data.low_stock_brands_count > 0) {
    lowCard.classList.add('alert');
    document.getElementById('metricLowStockSub').textContent = `มี ${data.low_stock_brands_count} สารทึบที่สต็อก ≤ 20 ขวด`;
  } else {
    lowCard.classList.remove('alert');
    document.getElementById('metricLowStockSub').textContent = 'สต็อกอยู่ในเกณฑ์ปกติทุกรายการ';
  }

  document.getElementById('metricNearExpCount').textContent = data.near_expiry_count || 0;
  document.getElementById('metricUsedMonth').textContent = (data.used_this_month || 0).toLocaleString();
  document.getElementById('metricUsedTodaySub').textContent = `วันนี้เบิกใช้: ${(data.used_today || 0).toLocaleString()} ขวด`;
}

// ==============================================================================
// 🏥 Render Dashboard Brand Cards (Sorted Alphabetically A-Z)
// ==============================================================================
function renderDashboardBrands(brands) {
  const container = document.getElementById('brandsGridContainer');
  if (!container) return;

  if (!brands || brands.length === 0) {
    container.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--text-muted);">ไม่พบข้อมูลสารทึบรังสี</div>`;
    return;
  }

  // Sort brands alphabetically A-Z
  brands.sort((a, b) => a.name.localeCompare(b.name));

  document.getElementById('dashboardBrandCount').textContent = `${brands.length} ชนิด`;

  const html = brands.map(b => {
    const isLow = b.total_remaining <= 20;
    const cardClass = isLow ? 'brand-card is-low-stock' : 'brand-card';
    
    // Brand initial letter
    const initial = b.name.charAt(0).toUpperCase();
    const brandAvatarClass = `brand-avatar ${b.name}`;

    // Expiration badge formatting
    let expBadgeHtml = '';
    if (!b.nearest_exp_date || b.total_remaining === 0) {
      expBadgeHtml = `<span class="exp-date-tag">ไม่มีสต็อก</span>`;
    } else {
      const daysLeft = getDaysUntil(b.nearest_exp_date);
      if (daysLeft < 0) {
        expBadgeHtml = `<span class="exp-date-tag expired">⚠️ หมดอายุแล้ว (${formatDate(b.nearest_exp_date)})</span>`;
      } else if (daysLeft <= 60) {
        expBadgeHtml = `<span class="exp-date-tag near-exp">⏳ อีก ${daysLeft} วัน (${formatDate(b.nearest_exp_date)})</span>`;
      } else {
        expBadgeHtml = `<span class="exp-date-tag">📅 ${formatDate(b.nearest_exp_date)} (อีก ${daysLeft} วัน)</span>`;
      }
    }

    // Red Alert Banner HTML (if <= 20 bottles)
    const redAlertHtml = isLow ? `
      <div class="red-alert-bar">
        <div class="alert-text">
          <span>🚨</span>
          <span><b>สต็อกเหลือน้อย (≤ 20 ขวด)</b> ควรเตรียมสั่งเพิ่ม</span>
        </div>
        <span class="alert-tag">คงเหลือ ${b.total_remaining} ขวด</span>
      </div>
    ` : '';

    // Specs Breakdown list
    let specsHtml = '';
    if (b.spec_breakdown && b.spec_breakdown.length > 0) {
      specsHtml = b.spec_breakdown.map(spec => `
        <div class="spec-item-row ${spec.remaining_qty <= 20 ? 'low-sub' : ''}">
          <span class="spec-title-text">
            <span>🔹</span> ${spec.concentration} mgI/ml (${spec.size_ml} ml)
          </span>
          <div style="display: flex; align-items: center; gap: 6px;">
            <span class="spec-qty-pill ${spec.remaining_qty <= 20 ? 'low' : ''}">${spec.remaining_qty} ขวด</span>
          </div>
        </div>
      `).join('');
    } else {
      specsHtml = `<div style="text-align: center; color: var(--text-light); font-size: 13px; padding: 10px 0;">ไม่มีรายการล็อตคงเหลือ</div>`;
    }

    return `
      <div class="${cardClass}">
        ${redAlertHtml}
        
        <div class="brand-card-top">
          <div class="brand-pill-title">
            <div class="${brandAvatarClass}">${initial}</div>
            <div class="brand-name-info">
              <h2>${escapeHtml(b.name)}</h2>
              <span>${b.lots_count} ล็อตในระบบ</span>
            </div>
          </div>

          <div class="brand-qty-badge">
            <div class="qty-number">${b.total_remaining.toLocaleString()}</div>
            <div class="qty-unit">ขวดคงเหลือ</div>
          </div>
        </div>

        <div class="brand-expiry-info">
          <span class="exp-label"><span>⏳</span> วันหมดอายุใกล้สุด:</span>
          ${expBadgeHtml}
        </div>

        <div class="brand-specs-list">
          ${specsHtml}
        </div>

        <div class="brand-card-footer">
          <button class="btn-card-use" onclick="openUsageModalWithBrand('${escapeHtml(b.name)}')">
            <span>💉</span> เบิกใช้
          </button>
          <button class="btn-card-add" onclick="openStockModalWithBrand('${escapeHtml(b.name)}')">
            <span>➕</span> เพิ่ม Stock
          </button>
        </div>
      </div>
    `;
  }).join('');

  container.innerHTML = html;
}

// ==============================================================================
// 📦 Render Stock Batches Table (Tab 2)
// ==============================================================================
function renderStockTable() {
  const tbody = document.getElementById('stockTableBody');
  if (!tbody) return;

  const search = (document.getElementById('stockSearchInput')?.value || '').toLowerCase().trim();
  const brand = document.getElementById('stockBrandFilter')?.value || '';
  const status = document.getElementById('stockStatusFilter')?.value || 'active';

  let filtered = allStocks.filter(item => {
    // Search text
    if (search) {
      const matchSearch = 
        item.name.toLowerCase().includes(search) ||
        item.lot_number.toLowerCase().includes(search) ||
        item.created_by.toLowerCase().includes(search) ||
        (item.notes && item.notes.toLowerCase().includes(search));
      if (!matchSearch) return false;
    }

    // Brand filter
    if (brand && item.name !== brand) return false;

    // Status filter
    if (status === 'active' && item.remaining_qty <= 0) return false;
    if (status === 'low' && (item.remaining_qty > 20 || item.remaining_qty <= 0)) return false;

    return true;
  });

  // Sort alphabetically by name (A-Z), then by expiration date ASC
  filtered.sort((a, b) => a.name.localeCompare(b.name) || (new Date(a.exp_date) - new Date(b.exp_date)));

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="11" style="text-align: center; padding: 30px; color: var(--text-muted);">ไม่พบข้อมูลล็อตสารทึบรังสีที่ตรงกับเงื่อนไข</td></tr>`;
    return;
  }

  const html = filtered.map((item, idx) => {
    const isLow = item.remaining_qty > 0 && item.remaining_qty <= 20;
    const isEmpty = item.remaining_qty <= 0;
    const rowClass = isLow ? 'row-low-stock' : '';

    let statusTag = '';
    if (isEmpty) {
      statusTag = `<span class="table-tag tag-empty">หมดสต็อก</span>`;
    } else if (isLow) {
      statusTag = `<span class="table-tag tag-low">🚨 สต็อกต่ำ (≤20)</span>`;
    } else {
      statusTag = `<span class="table-tag tag-ok">🟢 ปกติ</span>`;
    }

    const daysLeft = getDaysUntil(item.exp_date);
    let expTag = '';
    if (daysLeft < 0) {
      expTag = `<span style="color: var(--alert-red); font-weight: 600;">${formatDate(item.exp_date)} (หมดอายุ)</span>`;
    } else if (daysLeft <= 60) {
      expTag = `<span style="color: #B45309; font-weight: 600;">${formatDate(item.exp_date)} (${daysLeft} วัน)</span>`;
    } else {
      expTag = `<span>${formatDate(item.exp_date)}</span>`;
    }

    return `
      <tr class="${rowClass}">
        <td style="color: var(--text-muted); font-size: 12px; font-weight: 600;">${idx + 1}</td>
        <td>
          <span class="table-tag tag-brand">${escapeHtml(item.name)}</span>
        </td>
        <td><b>${escapeHtml(item.concentration)}</b> mgI/ml</td>
        <td>${item.size_ml} ml</td>
        <td><code style="background: #F1F3F9; padding: 2px 6px; border-radius: 6px; font-weight: 600; color: #4A5568;">${escapeHtml(item.lot_number)}</code></td>
        <td>${expTag}</td>
        <td>
          <b style="font-size: 15px; color: ${isLow ? 'var(--alert-red)' : '#2D3748'};">${item.remaining_qty}</b> 
          <span style="color: var(--text-light); font-size: 12px;">/ ${item.initial_qty} ขวด</span>
        </td>
        <td>${statusTag}</td>
        <td>${escapeHtml(item.created_by)}</td>
        <td style="font-size: 12px; color: var(--text-muted);">${formatDateTime(item.created_at)}</td>
        <td style="text-align: center;">
          ${item.remaining_qty > 0 ? `
            <button class="btn btn-pastel-pink btn-sm" onclick="openUsageModalWithLot(${item.id})" title="เบิกใช้ล็อตนี้">
              <span>💉</span> เบิก
            </button>
          ` : `
            <span style="color: var(--text-light); font-size: 12px;">-</span>
          `}
        </td>
      </tr>
    `;
  }).join('');

  tbody.innerHTML = html;
}

function filterStockTable() {
  renderStockTable();
}

// ==============================================================================
// 📋 Usage Logs (Tab 3)
// ==============================================================================
async function loadUsageLogs() {
  const tbody = document.getElementById('usageTableBody');
  if (!tbody) return;

  const search = (document.getElementById('usageSearchInput')?.value || '').trim();
  const brand = document.getElementById('usageBrandFilter')?.value || '';
  const startDate = document.getElementById('usageStartDate')?.value || '';
  const endDate = document.getElementById('usageEndDate')?.value || '';

  const params = new URLSearchParams();
  if (search) params.append('search', search);
  if (brand) params.append('name', brand);
  if (startDate) params.append('start_date', startDate);
  if (endDate) params.append('end_date', endDate);

  try {
    const res = await fetch(`/api/usage?${params.toString()}`);
    if (res.ok) {
      allUsages = await res.json();
      renderUsageTable(allUsages);
    }
  } catch (err) {
    console.error('Error fetching usage logs:', err);
  }
}

function renderUsageTable(logs) {
  const tbody = document.getElementById('usageTableBody');
  if (!tbody) return;

  if (!logs || logs.length === 0) {
    tbody.innerHTML = `<tr><td colspan="11" style="text-align: center; padding: 30px; color: var(--text-muted);">ยังไม่มีประวัติการเบิกใช้สารทึบรังสีตามเงื่อนไขที่เลือก</td></tr>`;
    return;
  }

  const html = logs.map((log, idx) => `
    <tr>
      <td style="color: var(--text-muted); font-size: 12px; font-weight: 600;">${idx + 1}</td>
      <td><b>${formatDate(log.used_date)}</b></td>
      <td><span class="table-tag tag-brand">${escapeHtml(log.name)}</span></td>
      <td>${escapeHtml(log.concentration)} mgI/ml</td>
      <td>${log.size_ml} ml</td>
      <td><code style="background: #F1F3F9; padding: 2px 6px; border-radius: 6px; font-weight: 600;">${escapeHtml(log.lot_number)}</code></td>
      <td><b style="color: var(--pastel-pink); font-size: 15px;">${log.qty_used}</b> ขวด</td>
      <td><b>${escapeHtml(log.used_by)}</b></td>
      <td style="color: var(--text-muted); font-size: 13px;">${escapeHtml(log.notes || '-')}</td>
      <td style="font-size: 12px; color: var(--text-muted);">${formatDateTime(log.created_at)}</td>
      <td style="text-align: center;">
        <button class="btn btn-pastel-outline btn-sm" onclick="cancelUsage(${log.id})" title="ยกเลิกรายการเบิกนี้และคืนสต็อก" style="color: var(--alert-red); border-color: var(--alert-red-border);">
          ✕ ยกเลิก
        </button>
      </td>
    </tr>
  `).join('');

  tbody.innerHTML = html;
}

function resetUsageFilters() {
  document.getElementById('usageSearchInput').value = '';
  document.getElementById('usageStartDate').value = '';
  document.getElementById('usageEndDate').value = '';
  document.getElementById('usageBrandFilter').value = '';
  loadUsageLogs();
}

async function cancelUsage(id) {
  if (!confirm('คุณแน่ใจหรือไม่ว่าต้องการยกเลิกรายการเบิกนี้? ระบบจะคืนจำนวนขวดกลับเข้าสู่สต็อกล็อตเดิม')) {
    return;
  }

  try {
    const res = await fetch(`/api/usage?id=${id}`, { method: 'DELETE' });
    const data = await res.json();
    if (res.ok && data.success) {
      showToast(data.message || 'ยกเลิกรายการเบิกและคืนสต็อกสำเร็จ', 'success');
      await refreshAllData();
      await loadUsageLogs();
    } else {
      showToast(data.message || 'เกิดข้อผิดพลาดในการยกเลิก', 'error');
    }
  } catch (err) {
    showToast('เกิดข้อผิดพลาดในการเชื่อมต่อ', 'error');
  }
}

// ==============================================================================
// 📦 Stock In Registration (Modal 1)
// ==============================================================================
function openStockModal() {
  document.getElementById('stockForm').reset();
  const savedRecorder = localStorage.getItem('last_contrast_recorder');
  if (savedRecorder) {
    document.getElementById('formStockRecorder').value = savedRecorder;
  }
  openModal('stockModal');
}

function openStockModalWithBrand(brandName) {
  openStockModal();
  const select = document.getElementById('formStockName');
  if (select) select.value = brandName;
}

async function submitStockForm(e) {
  e.preventDefault();
  const btn = document.getElementById('btnSubmitStock');
  btn.disabled = true;
  btn.textContent = 'กำลังบันทึก...';

  const name = document.getElementById('formStockName').value;
  const concentration = document.getElementById('formStockConcentration').value;
  const size_ml = parseInt(document.getElementById('formStockSize').value, 10);
  const lot_number = document.getElementById('formStockLot').value.trim();
  const quantity = parseInt(document.getElementById('formStockQty').value, 10);
  const exp_date = document.getElementById('formStockExp').value;
  const created_by = document.getElementById('formStockRecorder').value.trim();
  const notes = document.getElementById('formStockNotes').value.trim();

  // Save recorder name to localStorage
  localStorage.setItem('last_contrast_recorder', created_by);

  try {
    const res = await fetch('/api/stock', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name,
        concentration,
        size_ml,
        lot_number,
        quantity,
        exp_date,
        created_by,
        notes
      })
    });

    const data = await res.json();
    if (res.ok && data.success) {
      showToast('บันทึกรับเข้า Stock สำเร็จเรียบร้อยแล้ว 🌸', 'success');
      closeModal('stockModal');
      await refreshAllData();
    } else {
      showToast(data.message || 'ไม่สามารถบันทึกได้', 'error');
    }
  } catch (err) {
    showToast('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์', 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<span>💾</span> บันทึกเข้า Stock`;
  }
}

// ==============================================================================
// 💉 Usage Registration (Modal 2 - Sorted A-Z and FEFO)
// ==============================================================================
function populateUsageStockDropdown(selectedStockId = null, filterBrand = null) {
  const select = document.getElementById('formUsageStockId');
  if (!select) return;

  // Active stocks with remaining > 0
  let activeLots = allStocks.filter(s => s.remaining_qty > 0);
  if (filterBrand) {
    activeLots = activeLots.filter(s => s.name.toLowerCase() === filterBrand.toLowerCase());
  }

  // Sort alphabetically by Contrast Media name (A-Z), then by Expiration Date ASC (FEFO within brand)
  activeLots.sort((a, b) => a.name.localeCompare(b.name) || (new Date(a.exp_date) - new Date(b.exp_date)));

  if (activeLots.length === 0) {
    select.innerHTML = `<option value="">-- ไม่มีรายการสต็อกที่พร้อมเบิกใช้ --</option>`;
    document.getElementById('usageStockInfoBox').style.display = 'none';
    return;
  }

  let optionsHtml = `<option value="">-- เลือก LOT สารทึบรังสี (เรียงตามตัวอักษร A-Z และวันหมดอายุ) --</option>`;
  activeLots.forEach((lot, idx) => {
    const daysLeft = getDaysUntil(lot.exp_date);
    const expText = daysLeft < 0 ? `[หมดอายุ!]` : `[EXP: ${formatDate(lot.exp_date)} - เหลืออีก ${daysLeft} วัน]`;
    optionsHtml += `<option value="${lot.id}" ${selectedStockId == lot.id ? 'selected' : ''}>${lot.name} ${lot.concentration} mgI/ml (${lot.size_ml} ml) - LOT: ${lot.lot_number} | คงเหลือ ${lot.remaining_qty} ขวด ${expText}</option>`;
  });

  select.innerHTML = optionsHtml;

  if (selectedStockId) {
    select.value = selectedStockId;
  } else if (activeLots.length > 0) {
    select.value = activeLots[0].id;
  }

  onUsageStockSelected();
}

function onUsageStockSelected() {
  const select = document.getElementById('formUsageStockId');
  const stockId = parseInt(select?.value, 10);
  const infoBox = document.getElementById('usageStockInfoBox');
  const qtyInput = document.getElementById('formUsageQty');

  if (!stockId) {
    if (infoBox) infoBox.style.display = 'none';
    return;
  }

  const selectedLot = allStocks.find(s => s.id === stockId);
  if (selectedLot) {
    infoBox.style.display = 'block';
    document.getElementById('usageStockRemText').textContent = selectedLot.remaining_qty;
    
    const daysLeft = getDaysUntil(selectedLot.exp_date);
    const expTextTag = document.getElementById('usageStockExpText');
    expTextTag.textContent = `EXP: ${formatDate(selectedLot.exp_date)} (อีก ${daysLeft} วัน)`;
    if (daysLeft <= 60) {
      expTextTag.className = 'exp-date-tag near-exp';
    } else {
      expTextTag.className = 'exp-date-tag';
    }

    if (qtyInput) {
      qtyInput.max = selectedLot.remaining_qty;
      if (!qtyInput.value || parseInt(qtyInput.value, 10) > selectedLot.remaining_qty) {
        qtyInput.value = 1;
      }
    }
  }
}

function openUsageModal() {
  document.getElementById('usageForm').reset();
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('formUsageDate').value = today;

  const savedRecorder = localStorage.getItem('last_contrast_recorder');
  if (savedRecorder) {
    document.getElementById('formUsageRecorder').value = savedRecorder;
  }

  populateUsageStockDropdown();
  openModal('usageModal');
}

function openUsageModalWithBrand(brandName) {
  openUsageModal();
  populateUsageStockDropdown(null, brandName);
}

function openUsageModalWithLot(stockId) {
  openUsageModal();
  populateUsageStockDropdown(stockId);
}

async function submitUsageForm(e) {
  e.preventDefault();
  const btn = document.getElementById('btnSubmitUsage');
  btn.disabled = true;
  btn.textContent = 'กำลังบันทึก...';

  const stock_id = parseInt(document.getElementById('formUsageStockId').value, 10);
  const qty_used = parseInt(document.getElementById('formUsageQty').value, 10);
  const used_date = document.getElementById('formUsageDate').value;
  const used_by = document.getElementById('formUsageRecorder').value.trim();
  const notes = document.getElementById('formUsageNotes').value.trim();

  if (!stock_id) {
    showToast('กรุณาเลือกล็อตสารทึบรังสีที่จะเบิก', 'warning');
    btn.disabled = false;
    btn.innerHTML = `<span>💉</span> ยืนยันการเบิกใช้`;
    return;
  }

  // Save recorder name to localStorage
  localStorage.setItem('last_contrast_recorder', used_by);

  try {
    const res = await fetch('/api/usage', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        stock_id,
        qty_used,
        used_date,
        used_by,
        department: '',
        notes
      })
    });

    const data = await res.json();
    if (res.ok && data.success) {
      showToast('บันทึกการเบิกใช้สำเร็จเรียบร้อยแล้ว ✨', 'success');
      closeModal('usageModal');
      await refreshAllData();
    } else {
      showToast(data.message || 'ไม่สามารถบันทึกการเบิกได้', 'error');
    }
  } catch (err) {
    showToast('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์', 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<span>💉</span> ยืนยันการเบิกใช้`;
  }
}

// ==============================================================================
// 🖨️ Print & Report Export
// ==============================================================================
function printStockReport() {
  const printTimeText = document.getElementById('printTimestampText');
  if (printTimeText) {
    const now = new Date();
    printTimeText.textContent = `ข้อมูล ณ วันที่: ${now.toLocaleDateString('th-TH', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}`;
  }

  const prevTab = currentTab;
  switchTab('all-stock');
  setTimeout(() => {
    window.print();
    switchTab(prevTab);
  }, 300);
}

// ==============================================================================
// 📑 Tab Navigation
// ==============================================================================
function switchTab(tabId) {
  currentTab = tabId;

  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  
  const clickedBtn = Array.from(document.querySelectorAll('.tab-btn')).find(b => b.getAttribute('onclick')?.includes(tabId));
  if (clickedBtn) clickedBtn.classList.add('active');

  ['dashboard', 'all-stock', 'usage-logs', 'reports'].forEach(id => {
    const el = document.getElementById(`tab-${id}`);
    if (el) {
      el.style.display = (id === tabId) ? 'block' : 'none';
    }
  });

  if (tabId === 'usage-logs') {
    loadUsageLogs();
  } else if (tabId === 'all-stock') {
    renderStockTable();
  }
}

// ==============================================================================
// 🪟 Modal Helpers
// ==============================================================================
function openModal(modalId) {
  const el = document.getElementById(modalId);
  if (el) el.classList.add('show');
}

function closeModal(modalId) {
  const el = document.getElementById(modalId);
  if (el) el.classList.remove('show');
}

window.addEventListener('click', (e) => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('show');
  }
});

// ==============================================================================
// 🔔 Toast System
// ==============================================================================
function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  
  let icon = 'ℹ️';
  if (type === 'success') icon = '✅';
  if (type === 'error') icon = '❌';
  if (type === 'warning') icon = '⚠️';

  toast.innerHTML = `<span>${icon}</span> <span>${escapeHtml(message)}</span>`;
  container.appendChild(toast);

  setTimeout(() => toast.classList.add('show'), 10);

  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 400);
  }, 3500);
}

// ==============================================================================
// 🛠️ Date & Utility Helpers
// ==============================================================================
function getDaysUntil(dateString) {
  if (!dateString) return 9999;
  const target = new Date(dateString);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  target.setHours(0, 0, 0, 0);
  const diffTime = target - today;
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

function formatDate(dateStr) {
  if (!dateStr) return '-';
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    const year = parseInt(parts[0], 10);
    const thaiYear = year > 2500 ? year : year + 543;
    const months = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
    const month = months[parseInt(parts[1], 10) - 1] || parts[1];
    return `${parseInt(parts[2], 10)} ${month} ${thaiYear}`;
  }
  return dateStr;
}

function formatDateTime(dateTimeStr) {
  if (!dateTimeStr) return '-';
  const parts = dateTimeStr.split(' ');
  const datePart = formatDate(parts[0]);
  const timePart = parts[1] ? parts[1].substring(0, 5) : '';
  return `${datePart} ${timePart}`;
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
