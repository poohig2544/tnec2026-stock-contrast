// ==============================================================================
// 🌸 Cloudflare Pages Functions API Handler with Cloudflare D1 Database Binding
// ศูนย์รังสีร่วมรักษาระบบประสาท โรงพยาบาลตากสิน
// ==============================================================================

const STANDARD_BRANDS = ["Iomeron", "Iopamiro", "Omnipaque", "Optiray", "Ultravist", "Visipaque", "Xenetix"];

// Fallback demo data in case D1 binding is not yet attached
let mockStocks = [
  { id: 1, name: "Iomeron", concentration: "350", size_ml: 100, lot_number: "IM350-9921", initial_qty: 50, remaining_qty: 50, exp_date: "2027-08-31", created_by: "นร.ศุภชัย มั่นคง", notes: "สต็อกเริ่มต้นสำหรับระบบ", created_at: "2026-08-31 10:00:00", updated_at: "2026-08-31 10:00:00" },
  { id: 2, name: "Iopamiro", concentration: "300", size_ml: 50, lot_number: "IP300-1120", initial_qty: 35, remaining_qty: 19, exp_date: "2026-12-29", created_by: "นร.ศุภชัย มั่นคง", notes: "สต็อกเริ่มต้นสำหรับระบบ", created_at: "2026-08-31 10:00:00", updated_at: "2026-08-31 10:00:00" },
  { id: 3, name: "Omnipaque", concentration: "350", size_ml: 100, lot_number: "OP350-A241", initial_qty: 45, remaining_qty: 45, exp_date: "2027-02-27", created_by: "พว.สมศรี สถิตย์", notes: "สต็อกเริ่มต้นสำหรับระบบ", created_at: "2026-08-31 10:00:00", updated_at: "2026-08-31 10:00:00" },
  { id: 4, name: "Omnipaque", concentration: "300", size_ml: 50, lot_number: "OP300-B109", initial_qty: 25, remaining_qty: 18, exp_date: "2026-11-29", created_by: "นร.วิชัย รังสี", notes: "สต็อกเริ่มต้นสำหรับระบบ", created_at: "2026-08-31 10:00:00", updated_at: "2026-08-31 10:00:00" },
  { id: 5, name: "Optiray", concentration: "350", size_ml: 100, lot_number: "OPT35-4412", initial_qty: 40, remaining_qty: 32, exp_date: "2027-03-29", created_by: "พว.สมศรี สถิตย์", notes: "สต็อกเริ่มต้นสำหรับระบบ", created_at: "2026-08-31 10:00:00", updated_at: "2026-08-31 10:00:00" },
  { id: 6, name: "Ultravist", concentration: "370", size_ml: 100, lot_number: "UV370-5520", initial_qty: 60, remaining_qty: 52, exp_date: "2027-06-27", created_by: "พว.กานดา มีสุข", notes: "สต็อกเริ่มต้นสำหรับระบบ", created_at: "2026-08-31 10:00:00", updated_at: "2026-08-31 10:00:00" },
  { id: 7, name: "Visipaque", concentration: "320", size_ml: 100, lot_number: "VP320-X883", initial_qty: 30, remaining_qty: 15, exp_date: "2026-10-15", created_by: "พว.กานดา มีสุข", notes: "สต็อกเริ่มต้นสำหรับระบบ", created_at: "2026-08-31 10:00:00", updated_at: "2026-08-31 10:00:00" },
  { id: 8, name: "Xenetix", concentration: "300", size_ml: 50, lot_number: "XT300-7714", initial_qty: 20, remaining_qty: 10, exp_date: "2026-09-30", created_by: "นร.วิชัย รังสี", notes: "สต็อกเริ่มต้นสำหรับระบบ", created_at: "2026-08-31 10:00:00", updated_at: "2026-08-31 10:00:00" }
];

let mockUsages = [
  { id: 1, stock_id: 3, name: "Omnipaque", concentration: "350", size_ml: 100, lot_number: "OP350-A241", qty_used: 2, used_date: "2026-08-31", used_by: "นร.วิชัย รังสี", notes: "Case CTA Chest", created_at: "2026-08-31 11:30:00" }
];

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type"
    }
  });
}

function errorResponse(message, status = 400) {
  return jsonResponse({ error: true, message }, status);
}

// Ensure DB tables exist on first run
async function ensureDbInit(db) {
  if (!db) return;
  await db.exec(`
    CREATE TABLE IF NOT EXISTS contrast_stocks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      concentration TEXT NOT NULL,
      size_ml INTEGER NOT NULL,
      lot_number TEXT NOT NULL,
      initial_qty INTEGER NOT NULL,
      remaining_qty INTEGER NOT NULL,
      exp_date TEXT NOT NULL,
      created_by TEXT NOT NULL,
      notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS usage_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      stock_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      concentration TEXT NOT NULL,
      size_ml INTEGER NOT NULL,
      lot_number TEXT NOT NULL,
      qty_used INTEGER NOT NULL,
      used_date TEXT NOT NULL,
      used_by TEXT NOT NULL,
      department TEXT,
      notes TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (stock_id) REFERENCES contrast_stocks(id)
    );
    CREATE TABLE IF NOT EXISTS system_meta (
      key TEXT PRIMARY KEY,
      value TEXT
    );
  `);
}

async function bumpVersion(db) {
  const newV = Date.now().toString();
  if (db) {
    await db.prepare("INSERT OR REPLACE INTO system_meta (key, value) VALUES ('version', ?)").bind(newV).run();
  }
  return newV;
}

export async function onRequest(context) {
  const { request, env } = context;
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;

  if (method === "OPTIONS") {
    return new Response(null, {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
      }
    });
  }

  const db = env.DB; // Cloudflare D1 Database binding

  try {
    // --------------------------------------------------------------------------
    // 1. /api/sync-version
    // --------------------------------------------------------------------------
    if (path === "/api/sync-version") {
      if (db) {
        await ensureDbInit(db);
        const row = await db.prepare("SELECT value FROM system_meta WHERE key = 'version'").first();
        return jsonResponse({ version: row ? row.value : "1.0.0", timestamp: Date.now(), isD1: true });
      }
      return jsonResponse({ version: "1.0.0", timestamp: Date.now(), isD1: false });
    }

    // --------------------------------------------------------------------------
    // 2. /api/summary
    // --------------------------------------------------------------------------
    if (path === "/api/summary") {
      let activeStocks = [];
      let totalBottles = 0;
      let usedToday = 0;
      let usedThisMonth = 0;
      let nearExpiryCount = 0;
      let allBrandNames = [];

      const now = new Date();
      const todayStr = now.toISOString().split("T")[0];
      const monthStr = todayStr.substring(0, 7);
      const sixtyDaysLater = new Date(now.getTime() + 60 * 86400000).toISOString().split("T")[0];

      if (db) {
        await ensureDbInit(db);
        const totalRow = await db.prepare("SELECT COALESCE(SUM(remaining_qty), 0) as total FROM contrast_stocks WHERE remaining_qty > 0").first();
        totalBottles = totalRow ? totalRow.total : 0;

        const usedTodayRow = await db.prepare("SELECT COALESCE(SUM(qty_used), 0) as total FROM usage_logs WHERE used_date = ?").bind(todayStr).first();
        usedToday = usedTodayRow ? usedTodayRow.total : 0;

        const usedMonthRow = await db.prepare("SELECT COALESCE(SUM(qty_used), 0) as total FROM usage_logs WHERE used_date LIKE ?").bind(`${monthStr}%`).first();
        usedThisMonth = usedMonthRow ? usedMonthRow.total : 0;

        const nearExpRow = await db.prepare("SELECT COUNT(*) as count FROM contrast_stocks WHERE remaining_qty > 0 AND exp_date <= ?").bind(sixtyDaysLater).first();
        nearExpiryCount = nearExpRow ? nearExpRow.count : 0;

        const activeStocksRes = await db.prepare("SELECT * FROM contrast_stocks WHERE remaining_qty > 0 ORDER BY name ASC, exp_date ASC").all();
        activeStocks = activeStocksRes.results || [];

        const allNamesRes = await db.prepare("SELECT DISTINCT name FROM contrast_stocks").all();
        const dbNames = (allNamesRes.results || []).map(r => r.name);
        allBrandNames = Array.from(new Set([...STANDARD_BRANDS, ...dbNames])).sort();
      } else {
        // Mock fallback
        activeStocks = mockStocks.filter(s => s.remaining_qty > 0);
        totalBottles = activeStocks.reduce((sum, s) => sum + s.remaining_qty, 0);
        usedToday = mockUsages.filter(u => u.used_date === todayStr).reduce((sum, u) => sum + u.qty_used, 0);
        usedThisMonth = mockUsages.filter(u => u.used_date.startsWith(monthStr)).reduce((sum, u) => sum + u.qty_used, 0);
        nearExpiryCount = activeStocks.filter(s => s.exp_date <= sixtyDaysLater).length;
        allBrandNames = Array.from(new Set([...STANDARD_BRANDS, ...mockStocks.map(s => s.name)])).sort();
      }

      let lowStockBrandsCount = 0;
      const brandsSummary = allBrandNames.map(brand => {
        const matching = activeStocks.filter(s => s.name.toLowerCase() === brand.toLowerCase());
        const totalRemaining = matching.reduce((sum, s) => sum + (s.remaining_qty || 0), 0);
        
        const expDates = matching.map(s => s.exp_date).filter(Boolean).sort();
        const nearestExpDate = expDates[0] || null;

        const isLowStock = totalRemaining <= 20;
        if (isLowStock) lowStockBrandsCount++;

        const specMap = new Map();
        matching.forEach(item => {
          const key = `${item.concentration} mgI/ml - ${item.size_ml} ml`;
          if (!specMap.has(key)) {
            specMap.set(key, {
              spec_title: key,
              concentration: item.concentration,
              size_ml: item.size_ml,
              remaining_qty: 0,
              exp_dates: [],
              lots: []
            });
          }
          const specObj = specMap.get(key);
          specObj.remaining_qty += item.remaining_qty;
          specObj.exp_dates.push(item.exp_date);
          specObj.lots.push({
            id: item.id,
            lot_number: item.lot_number,
            remaining_qty: item.remaining_qty,
            initial_qty: item.initial_qty,
            exp_date: item.exp_date,
            created_by: item.created_by,
            notes: item.notes
          });
        });

        const specBreakdown = Array.from(specMap.values()).map(spec => ({
          spec_title: spec.spec_title,
          concentration: spec.concentration,
          size_ml: spec.size_ml,
          remaining_qty: spec.remaining_qty,
          nearest_exp_date: spec.exp_dates.sort()[0] || null,
          is_low_stock: spec.remaining_qty <= 20,
          lots: spec.lots
        }));

        return {
          name: brand,
          total_remaining: totalRemaining,
          nearest_exp_date: nearestExpDate,
          is_low_stock: isLowStock,
          lots_count: matching.length,
          spec_breakdown: specBreakdown,
          all_active_lots: matching
        };
      });

      return jsonResponse({
        total_bottles: totalBottles,
        low_stock_brands_count: lowStockBrandsCount,
        near_expiry_count: nearExpiryCount,
        used_today: usedToday,
        used_this_month: usedThisMonth,
        brands: brandsSummary,
        isD1Connected: !!db
      });
    }

    // --------------------------------------------------------------------------
    // 3. /api/stock
    // --------------------------------------------------------------------------
    if (path === "/api/stock") {
      if (method === "GET") {
        const includeEmpty = url.searchParams.get("all") === "1";
        if (db) {
          await ensureDbInit(db);
          const sql = includeEmpty
            ? "SELECT * FROM contrast_stocks ORDER BY CASE WHEN remaining_qty > 0 THEN 0 ELSE 1 END, name ASC, exp_date ASC"
            : "SELECT * FROM contrast_stocks WHERE remaining_qty > 0 ORDER BY name ASC, exp_date ASC";
          const res = await db.prepare(sql).all();
          return jsonResponse(res.results || []);
        } else {
          let res = includeEmpty ? [...mockStocks] : mockStocks.filter(s => s.remaining_qty > 0);
          res.sort((a, b) => a.name.localeCompare(b.name) || new Date(a.exp_date) - new Date(b.exp_date));
          return jsonResponse(res);
        }
      }

      if (method === "POST") {
        const data = await request.json();
        const name = (data.name || "").trim();
        const concentration = (data.concentration || "").toString().trim();
        const size_ml = parseInt(data.size_ml, 10);
        const lot_number = (data.lot_number || "").trim().toUpperCase();
        const quantity = parseInt(data.quantity, 10);
        const exp_date = (data.exp_date || "").trim();
        const created_by = (data.created_by || "").trim();
        const notes = (data.notes || "").trim();

        if (!name || !concentration || !size_ml || !lot_number || !quantity || !exp_date || !created_by) {
          return errorResponse("กรุณากรอกข้อมูลให้ครบถ้วน");
        }

        const nowStr = new Date().toISOString().replace("T", " ").substring(0, 19);

        if (db) {
          await ensureDbInit(db);
          const existing = await db.prepare(
            "SELECT * FROM contrast_stocks WHERE name = ? AND concentration = ? AND size_ml = ? AND lot_number = ? AND exp_date = ?"
          ).bind(name, concentration, size_ml, lot_number, exp_date).first();

          let newId;
          if (existing) {
            const newInitial = existing.initial_qty + quantity;
            const newRem = existing.remaining_qty + quantity;
            await db.prepare(
              "UPDATE contrast_stocks SET initial_qty = ?, remaining_qty = ?, updated_at = ?, notes = ? WHERE id = ?"
            ).bind(newInitial, newRem, nowStr, `${existing.notes || ""} | เพิ่มเติม ${quantity} ขวด โดย ${created_by}`, existing.id).run();
            newId = existing.id;
          } else {
            const insertRes = await db.prepare(
              `INSERT INTO contrast_stocks (name, concentration, size_ml, lot_number, initial_qty, remaining_qty, exp_date, created_by, notes, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
            ).bind(name, concentration, size_ml, lot_number, quantity, quantity, exp_date, created_by, notes, nowStr, nowStr).run();
            newId = insertRes.meta.last_row_id;
          }

          await bumpVersion(db);
          return jsonResponse({ success: true, message: "บันทึกสต็อกใหม่เรียบร้อยแล้ว", id: newId });
        } else {
          const existing = mockStocks.find(s => s.name === name && s.concentration === concentration && s.size_ml === size_ml && s.lot_number === lot_number && s.exp_date === exp_date);
          let newId;
          if (existing) {
            existing.initial_qty += quantity;
            existing.remaining_qty += quantity;
            existing.updated_at = nowStr;
            existing.notes = `${existing.notes || ''} | เพิ่มเติม ${quantity} ขวด โดย ${created_by}`;
            newId = existing.id;
          } else {
            newId = mockStocks.length > 0 ? Math.max(...mockStocks.map(s => s.id)) + 1 : 1;
            mockStocks.push({ id: newId, name, concentration, size_ml, lot_number, initial_qty: quantity, remaining_qty: quantity, exp_date, created_by, notes, created_at: nowStr, updated_at: nowStr });
          }
          return jsonResponse({ success: true, message: "บันทึกสต็อกใหม่เรียบร้อยแล้ว", id: newId });
        }
      }

      if (method === "DELETE") {
        const id = parseInt(url.searchParams.get("id"), 10);
        if (db) {
          const usageCountRow = await db.prepare("SELECT COUNT(*) as count FROM usage_logs WHERE stock_id = ?").bind(id).first();
          if (usageCountRow && usageCountRow.count > 0) return errorResponse("ไม่สามารถลบได้เนื่องจากมีประวัติการเบิกใช้แล้ว");
          await db.prepare("DELETE FROM contrast_stocks WHERE id = ?").bind(id).run();
          await bumpVersion(db);
          return jsonResponse({ success: true, message: "ลบรายการสต็อกเรียบร้อยแล้ว" });
        } else {
          mockStocks = mockStocks.filter(s => s.id !== id);
          return jsonResponse({ success: true, message: "ลบรายการสต็อกเรียบร้อยแล้ว" });
        }
      }
    }

    // --------------------------------------------------------------------------
    // 4. /api/usage
    // --------------------------------------------------------------------------
    if (path === "/api/usage") {
      if (method === "GET") {
        const limit = parseInt(url.searchParams.get("limit") || "100", 10);
        const search = (url.searchParams.get("search") || "").trim();
        const brand = (url.searchParams.get("name") || "").trim();
        const startDate = (url.searchParams.get("start_date") || "").trim();
        const endDate = (url.searchParams.get("end_date") || "").trim();

        if (db) {
          await ensureDbInit(db);
          const conditions = [];
          const params = [];
          if (search) {
            conditions.push("(name LIKE ? OR lot_number LIKE ? OR used_by LIKE ? OR notes LIKE ?)");
            const sParam = `%${search}%`;
            params.push(sParam, sParam, sParam, sParam);
          }
          if (brand) { conditions.push("name = ?"); params.push(brand); }
          if (startDate) { conditions.push("used_date >= ?"); params.push(startDate); }
          if (endDate) { conditions.push("used_date <= ?"); params.push(endDate); }

          const whereClause = conditions.length > 0 ? "WHERE " + conditions.join(" AND ") : "";
          const sql = `SELECT * FROM usage_logs ${whereClause} ORDER BY used_date DESC, id DESC LIMIT ${limit}`;
          const res = params.length > 0 ? await db.prepare(sql).bind(...params).all() : await db.prepare(sql).all();
          return jsonResponse(res.results || []);
        } else {
          let res = [...mockUsages];
          if (search) res = res.filter(u => u.name.toLowerCase().includes(search.toLowerCase()) || u.lot_number.toLowerCase().includes(search.toLowerCase()) || u.used_by.toLowerCase().includes(search.toLowerCase()) || (u.notes && u.notes.toLowerCase().includes(search.toLowerCase())));
          if (brand) res = res.filter(u => u.name === brand);
          if (startDate) res = res.filter(u => u.used_date >= startDate);
          if (endDate) res = res.filter(u => u.used_date <= endDate);
          res.sort((a, b) => new Date(b.used_date) - new Date(a.used_date) || b.id - a.id);
          return jsonResponse(res);
        }
      }

      if (method === "POST") {
        const data = await request.json();
        const stock_id = parseInt(data.stock_id, 10);
        const qty_used = parseInt(data.qty_used, 10);
        const used_date = (data.used_date || "").trim();
        const used_by = (data.used_by || "").trim();
        const notes = (data.notes || "").trim();

        if (!stock_id || !qty_used || !used_date || !used_by) {
          return errorResponse("กรุณากรอกข้อมูลให้ครบถ้วน");
        }

        const nowStr = new Date().toISOString().replace("T", " ").substring(0, 19);

        if (db) {
          await ensureDbInit(db);
          const stock = await db.prepare("SELECT * FROM contrast_stocks WHERE id = ?").bind(stock_id).first();
          if (!stock) return errorResponse("ไม่พบรายการสต็อกที่เลือก");
          const rem = stock.remaining_qty;
          if (rem < qty_used) return errorResponse(`จำนวนคงเหลือมีเพียง ${rem} ขวด`);

          const newRem = rem - qty_used;
          await db.batch([
            db.prepare("UPDATE contrast_stocks SET remaining_qty = ?, updated_at = ? WHERE id = ?").bind(newRem, nowStr, stock_id),
            db.prepare(`INSERT INTO usage_logs (stock_id, name, concentration, size_ml, lot_number, qty_used, used_date, used_by, department, notes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(stock_id, stock.name, stock.concentration, stock.size_ml, stock.lot_number, qty_used, used_date, used_by, "", notes, nowStr)
          ]);
          await bumpVersion(db);
          return jsonResponse({ success: true, message: "บันทึกการเบิกใช้สำเร็จเรียบร้อยแล้ว" });
        } else {
          const stock = mockStocks.find(s => s.id === stock_id);
          if (!stock) return errorResponse("ไม่พบรายการสต็อก");
          if (stock.remaining_qty < qty_used) return errorResponse(`จำนวนคงเหลือมีเพียง ${stock.remaining_qty} ขวด`);
          stock.remaining_qty -= qty_used;
          const newId = mockUsages.length > 0 ? Math.max(...mockUsages.map(u => u.id)) + 1 : 1;
          mockUsages.unshift({ id: newId, stock_id, name: stock.name, concentration: stock.concentration, size_ml: stock.size_ml, lot_number: stock.lot_number, qty_used, used_date, used_by, notes, created_at: nowStr });
          return jsonResponse({ success: true, message: "บันทึกการเบิกใช้สำเร็จเรียบร้อยแล้ว" });
        }
      }

      if (method === "DELETE") {
        const id = parseInt(url.searchParams.get("id"), 10);
        if (db) {
          const usage = await db.prepare("SELECT * FROM usage_logs WHERE id = ?").bind(id).first();
          if (!usage) return errorResponse("ไม่พบรายการเบิก");
          const nowStr = new Date().toISOString().replace("T", " ").substring(0, 19);
          await db.batch([
            db.prepare("UPDATE contrast_stocks SET remaining_qty = remaining_qty + ?, updated_at = ? WHERE id = ?").bind(usage.qty_used, nowStr, usage.stock_id),
            db.prepare("DELETE FROM usage_logs WHERE id = ?").bind(id)
          ]);
          await bumpVersion(db);
          return jsonResponse({ success: true, message: "ยกเลิกรายการเบิกใช้เรียบร้อยแล้ว" });
        } else {
          const idx = mockUsages.findIndex(u => u.id === id);
          if (idx !== -1) {
            const u = mockUsages[idx];
            const stock = mockStocks.find(s => s.id === u.stock_id);
            if (stock) stock.remaining_qty += u.qty_used;
            mockUsages.splice(idx, 1);
          }
          return jsonResponse({ success: true, message: "ยกเลิกรายการเบิกใช้เรียบร้อยแล้ว" });
        }
      }
    }

    // --------------------------------------------------------------------------
    // 5. /api/export/usage.csv
    // --------------------------------------------------------------------------
    if (path === "/api/export/usage.csv") {
      let rows = [];
      if (db) {
        await ensureDbInit(db);
        const res = await db.prepare("SELECT * FROM usage_logs ORDER BY used_date DESC, id DESC").all();
        rows = res.results || [];
      } else {
        rows = mockUsages;
      }

      const todayStr = new Date().toISOString().split("T")[0];
      let csv = "ลำดับ,วันที่ใช้,ชื่อสารทึบรังสี,ความเข้มข้น (mgI/ml),ขนาดบรรจุ (ml),หมายเลข LOT,จำนวนที่ใช้ (ขวด),ผู้บันทึกการใช้,หมายเหตุ,เวลาที่บันทึกระบบ\r\n";
      rows.forEach((r, idx) => {
        const line = [
          idx + 1,
          `"${r.used_date}"`,
          `"${r.name}"`,
          `"${r.concentration}"`,
          r.size_ml,
          `"${r.lot_number}"`,
          r.qty_used,
          `"${r.used_by}"`,
          `"${(r.notes || '-').replace(/"/g, '""')}"`,
          `"${r.created_at}"`
        ].join(",");
        csv += line + "\r\n";
      });

      const filename = `contrast_usage_report_${todayStr.replace(/-/g, "")}.csv`;
      return new Response("\uFEFF" + csv, {
        headers: {
          "Content-Type": "text/csv; charset=utf-8",
          "Content-Disposition": `attachment; filename="${filename}"`
        }
      });
    }

    // --------------------------------------------------------------------------
    // 6. /api/export/stock.csv
    // --------------------------------------------------------------------------
    if (path === "/api/export/stock.csv") {
      let rows = [];
      if (db) {
        await ensureDbInit(db);
        const res = await db.prepare("SELECT * FROM contrast_stocks ORDER BY CASE WHEN remaining_qty > 0 THEN 0 ELSE 1 END, name ASC, exp_date ASC").all();
        rows = res.results || [];
      } else {
        rows = mockStocks;
      }

      const todayStr = new Date().toISOString().split("T")[0];
      let csv = "ลำดับ,ชื่อสารทึบรังสี,ความเข้มข้น (mgI/ml),ขนาดบรรจุ (ml),หมายเลข LOT,วันหมดอายุ (EXP),คงเหลือ (ขวด),รับเข้าเดิม (ขวด),สถานะสต็อก,ผู้บันทึกรับเข้า,หมายเหตุ,วันที่บันทึก\r\n";
      rows.forEach((r, idx) => {
        let status = "ปกติ";
        if (r.remaining_qty <= 0) status = "หมดสต็อก";
        else if (r.remaining_qty <= 20) status = "สต็อกเหลือน้อย (<= 20 ขวด)";

        const line = [
          idx + 1,
          `"${r.name}"`,
          `"${r.concentration}"`,
          r.size_ml,
          `"${r.lot_number}"`,
          `"${r.exp_date}"`,
          r.remaining_qty,
          r.initial_qty,
          `"${status}"`,
          `"${r.created_by}"`,
          `"${(r.notes || '-').replace(/"/g, '""')}"`,
          `"${r.created_at}"`
        ].join(",");
        csv += line + "\r\n";
      });

      const filename = `contrast_stock_inventory_${todayStr.replace(/-/g, "")}.csv`;
      return new Response("\uFEFF" + csv, {
        headers: {
          "Content-Type": "text/csv; charset=utf-8",
          "Content-Disposition": `attachment; filename="${filename}"`
        }
      });
    }

    return errorResponse("API Endpoint Not Found", 404);

  } catch (err) {
    return errorResponse(`Server Error: ${err.message}`, 500);
  }
}
